<?php
    header("location:page/filiere.php");
?>