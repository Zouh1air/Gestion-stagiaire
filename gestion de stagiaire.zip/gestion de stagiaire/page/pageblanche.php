<!doctype html>
<HTML>
 <HEAD>
    <meta charest="utf-8">
  <ti>page blanche  </ti>
  <link rel ="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <link rel ="stylesheet" type="text/css" href="../css/mystyle.css">
 </HEAD>
<BODY>
  <?php include("menu.php");?>
  <div class ="container">
    <div class ="panel panel-success  margetop">
        <div class="panel-heading">Rechercher des stagiaires...</div>
        <div class="panel-body">
            le contenu du panneau 
        </div>
    </div>

    <div class ="panel panel-primary">
        <div class="panel-heading">lister les stagiaires...</div>
        <div class="panel-body">
            le tableau des stagiaires
        </div>
    </div>
    </BODY>
</HTML>